<?php /* Static Name: Footer Logo */ ?>
<a href="http://www.templatemonster.com/" rel="nofollow" target="_blank">
		<img src="<?php echo of_get_option('footer_logo_url', '' ); ?>" alt="<?php bloginfo('name'); ?>" title="<?php bloginfo('description'); ?>">
</a>
